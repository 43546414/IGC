---
title: Plae
---

#####Plae

Ergonomically designed, washable, and customizable kids’ shoes in an endless array of color schemes that let kids PLAE in fashionable comfort.

<a href="https://www.goplae.com/" target="_blank">goplae.com</a>
